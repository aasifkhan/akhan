function foodemo(value) {
    if(value=='a' || value=='e' | value=='i' || value=='o' || value=='u') {
	return true;
    }
    else {
	return false;
    }
}

function funct(a, foo) {
    console.log(foo(a));
}

funct('u', foodemo);