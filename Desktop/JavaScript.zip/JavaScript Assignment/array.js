function func(arr) {
    var i;
    var p=0;
    var arr1=[];
    for(i=0;i<8;i++) {
	if((arr[i]%2)===0){
	    arr1[p]=arr[i];
	    p++;
	}
    }
    return arr1;
}
arr23=[12,13,44,55,66,89,9,10];
console.log(func(arr23));

