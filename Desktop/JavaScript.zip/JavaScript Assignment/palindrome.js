function func(a) {
    var t,r=0;
    temp=a;
    while(a>0) {
        r=(r*10)+(a%10);
        a=Math.floor(a/10);
    }  
    if(r===temp) {
	return true;
    }
    else {
	return false;
    }
}
console.log(func(121));
