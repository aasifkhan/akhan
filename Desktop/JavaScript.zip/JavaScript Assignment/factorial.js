function func(a) {
    var fact=1;
    for(i=1;i<=a;i++) {
        fact=fact*i;
    }  
    return fact;
}
console.log(func(7));
