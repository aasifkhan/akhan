function display(n) {
    var a=-1;
    var b=1;
    var lim=0;
    while(lim<n) {
	c=a+b;
	console.log(c+" ");
	a=b;
	b=c;
	lim=lim+1;
    }
}
display(10);
